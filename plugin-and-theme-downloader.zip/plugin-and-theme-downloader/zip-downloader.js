jQuery(document).ready(function($) {
    $('#zip-downloader-form').submit(function(e) {
        e.preventDefault();

        var formData = {
            action: 'download_zip',
            nonce: zipDownloader.nonce,
            zip_url: $('input[name="zip_url"]').val(),
            type: $('select[name="type"]').val()
        };

        $('#progress-bar').show();
        $('#progress-bar-fill').css('width', '0%');
        $('#message').html('');

        $.ajax({
            url: zipDownloader.ajax_url,
            type: 'POST',
            data: formData,
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = evt.loaded / evt.total;
                        percentComplete = parseInt(percentComplete * 100);
                        $('#progress-bar-fill').css('width', percentComplete + '%');
                    }
                }, false);
                return xhr;
            },
            success: function(response) {
                if (response.success) {
                    $('#message').html('<div class="notice notice-success is-dismissible"><p>' + response.data.message + '</p></div>');
                } else {
                    $('#message').html('<div class="notice notice-error is-dismissible"><p>' + response.data.message + '</p></div>');
                }
                $('#progress-bar').hide();
            },
            error: function(xhr, status, error) {
                $('#message').html('<div class="notice notice-error is-dismissible"><p>Failed to process the request: ' + error + '</p></div>');
                $('#progress-bar').hide();
            }
        });
    });
});
