<?php
/**
 * Plugin Name: ZIP File Downloader and Extractor with Progress
 * Description: Download and extract ZIP files into theme or plugin directories with progress bar.
 * Version: 1.1
 * Author: Hamid Ahangaryan
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class ZIP_File_Downloader_Extractor {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_download_zip', array($this, 'download_and_extract_zip'));
    }

    public function add_admin_menu() {
        add_menu_page(
            'ZIP Downloader', 
            'ZIP Downloader', 
            'manage_options', 
            'zip-downloader', 
            array($this, 'create_admin_page')
        );
    }

    public function enqueue_scripts($hook) {
        if ($hook != 'toplevel_page_zip-downloader') {
            return;
        }
        wp_enqueue_script('zip-downloader-js', plugin_dir_url(__FILE__) . 'zip-downloader.js', array('jquery'), null, true);
        wp_localize_script('zip-downloader-js', 'zipDownloader', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('zip_downloader_nonce'),
        ));
    }

    public function create_admin_page() {
        ?>
        <div class="wrap">
            <h1>Download and Extract ZIP File</h1>
            <form id="zip-downloader-form">
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">ZIP File URL</th>
                        <td><input type="text" name="zip_url" value="" size="50" required /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Type</th>
                        <td>
                            <select name="type" required>
                                <option value="theme">Theme</option>
                                <option value="plugin">Plugin</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <p class="submit"><input type="submit" class="button-primary" value="Download and Extract" /></p>
            </form>
            <div id="progress-bar" style="display:none; width:100%; background:#e0e0e0;">
                <div id="progress-bar-fill" style="width:0%; height:30px; background:#4caf50;"></div>
            </div>
            <div id="message"></div>
        </div>
        <?php
    }

    public function download_and_extract_zip() {
        check_ajax_referer('zip_downloader_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized user'));
        }

        if (isset($_POST['zip_url']) && isset($_POST['type'])) {
            $zip_url = esc_url_raw($_POST['zip_url']);
            $type = sanitize_text_field($_POST['type']);

            // Define the path where to save the ZIP file
            $upload_dir = wp_upload_dir();
            $zip_path = $upload_dir['basedir'] . '/temp.zip';

            // Download the ZIP file
            $response = wp_remote_get($zip_url, array('timeout' => 300));

            if (is_wp_error($response)) {
                wp_send_json_error(array('message' => 'Failed to download ZIP file: ' . $response->get_error_message()));
            }

            // Save the ZIP file
            $zip_content = wp_remote_retrieve_body($response);
            if (empty($zip_content)) {
                wp_send_json_error(array('message' => 'Failed to retrieve ZIP file content.'));
            }

            file_put_contents($zip_path, $zip_content);

            // Determine the extraction path
            if ($type == 'theme') {
                $extract_to = get_theme_root();
            } elseif ($type == 'plugin') {
                $extract_to = WP_PLUGIN_DIR;
            } else {
                wp_send_json_error(array('message' => 'Invalid type specified.'));
            }

            // Extract the ZIP file
            $zip = new ZipArchive;
            if ($zip->open($zip_path) === TRUE) {
                $zip->extractTo($extract_to);
                $zip->close();
                unlink($zip_path); // Delete the temporary ZIP file
                wp_send_json_success(array('message' => 'ZIP file successfully downloaded and extracted.'));
            } else {
                wp_send_json_error(array('message' => 'Failed to extract ZIP file.'));
            }
        } else {
            wp_send_json_error(array('message' => 'Invalid data submitted.'));
        }
    }
}

new ZIP_File_Downloader_Extractor();
?>
